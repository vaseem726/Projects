#include<stdio.h>
#include<string.h>
#include "sll.h"

// Function to save the hash map database to a file with .txt extension
int save(hash *arr, char *str) {
    
    // Check if the specified filename has a .txt extension
    if (strstr(str, ".txt") == NULL) {
        printf("File is not .txt Extension\n");
        return FAILURE;
    }
    
    // Attempt to open the file in write mode
    FILE *fp = fopen(str, "w");
    if (fp == NULL) {
        printf("File is not opened\n");
        return FAILURE;
    }
    
    // Iterate over each index of the hash array
    for (int i = 0; i < 28; i++) {
        // Check if the current index has data (non-NULL h_link indicates entries are present)
        if (arr[i].h_link != NULL) {
            // Traverse the main linked list at this index
            Main *temp = arr[i].h_link;
            while (temp != NULL) {
                // Write the index to the file, prefixed by "#" to mark the start of a record
                fprintf(fp, "%s%d;", "#", i);

                // Write the word and its file count
                fprintf(fp, "%s;%d;", temp->word, temp->file_count);

                // Traverse the sub-list to write each file name and word count for this word
                Sub *t = temp->Msub_link;
                while (t != NULL) {
                    fprintf(fp, "%s;%d;", t->file_name, t->word_count);
                    t = t->sub_link;  // Move to the next file in the sub-list
                }
                
                // End the current entry in the file with "#" to indicate the end of a record
                fprintf(fp, "%s;\n", "#");
                
                // Move to the next word entry in the main linked list
                temp = temp->main_link;
            }
        }
    }
    
    // Close the file after writing all data
    fclose(fp);
    return SUCCESS;
}

