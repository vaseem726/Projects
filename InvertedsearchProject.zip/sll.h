#ifndef SLL_H
#define SLL_H

#include <stdio.h>
#include <stdlib.h>

// Constants for return values indicating status of operations
#define SUCCESS 0
#define FAILURE -1
#define DATA_NOT_FOUND -2
#define LIST_EMPTY -4

// Maximum length for file data and buffer sizes
#define MAX 100
typedef char data_t;  // Define a type alias for `data_t`, representing character data

// Definition of the basic node structure for a linked list
typedef struct node {
    data_t data[MAX];      // Stores file name or other data
    struct node *link;     // Pointer to the next node in the list
} Slist;

// Structure to hold information about each file containing a specific word
typedef struct subnode {
    char file_name[10];        // Stores the file name (assumed to be <= 10 chars)
    int word_count;            // Number of times the word appears in this file
    struct subnode *sub_link;  // Pointer to the next file node in the sub-list
} Sub;

// Structure for the main node that represents each unique word in the hash map
typedef struct mainnode {
    char word[10];               // Word itself (assumed <= 10 chars)
    int file_count;              // Number of files containing this word
    struct subnode *Msub_link;   // Pointer to the linked list of files containing the word
    struct mainnode *main_link;  // Pointer to the next word node in the main linked list
} Main;

// Structure for each index in the hash array, representing linked list of words
typedef struct hash {
    Main *h_link;  // Head pointer to the main linked list for each hash index
} hash;

// Function Prototypes

// Reads and validates file names from the command line arguments and inserts into list
int Read_and_validate(char *argv, Slist **head);

// Opens file and checks its content to ensure it can be processed
int openfile_and_check_content(char *argv, Slist **head);

// Checks if a file has already been added to the list (to avoid duplicates)
int check_duplicate(char *argv, Slist **head);

// Adds a file name to the linked list
int add_list(char *argv, Slist **head);

// Creates a hash map from the list of files, storing words and associated files
int create_hash_map(hash *arr, Slist **head);

// Displays the contents of the hash map, showing words and files with occurrence counts
int display(hash *arr);

// Searches for a specific word in the hash map
int Search_Word(hash *arr, char *word);

// Saves the hash map data to a file
int save(hash *arr, char *str);

// Updates the hash map with additional files or data changes
int Update(hash *arr, char *str1, char[][MAX], int *c);

#endif  // End of SLL_H header guard

