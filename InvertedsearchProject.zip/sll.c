#include <stdio.h>
#include <string.h>
#include "sll.h"

// Function to read and validate the provided file name (argv) and add it to the list
int Read_and_validate(char *argv, Slist **head) {
    // Check if the file name (argv) is not NULL
    if (argv != NULL) {
        
        // Check if the file has a ".txt" extension
        if (strstr(argv, ".txt") != NULL) {
            
            // Check if the file can be opened and has content
            if (openfile_and_check_content(argv, head) == SUCCESS) {
                
                // Check if the file is not already in the list (to avoid duplicates)
                if (check_duplicate(argv, head) == SUCCESS) {
                    
                    // Add the file name to the linked list
                    if (add_list(argv, head) == SUCCESS) {
                        return SUCCESS;  // Successfully validated and added the file
                    } else {
                        printf("File is not added in list: %s\n", argv);
                        return FAILURE;
                    }

                } else {
                    // File is a duplicate, so it won't be added again
                    printf("This is %s\n duplicate element", argv);
                    return FAILURE;
                }

            } else {
                // File could not be opened or does not contain any content
                printf("File is not opened: %s\n", argv);
                return FAILURE;
            }
            
        } else {
            // File does not have the required ".txt" extension
            printf("File is not .txt extension: %s\n", argv);
            return FAILURE;
        }

    } else {
        // File name (argv) is NULL, indicating it wasn't provided or read correctly
        printf("File is not there: %s\n", argv);
        return FAILURE;
    }
}

// Function to open the file and check if it contains any content
int openfile_and_check_content(char *argv, Slist **head) {
    FILE *fp = fopen(argv, "r");  // Attempt to open the file in read mode
    if (fp == NULL) {
        // File could not be opened
        printf("file is not opened: %s\n", argv);
        return FAILURE;
    }

    // Move to the end of the file to check its size
    fseek(fp, 0, SEEK_END);
    long k = ftell(fp);  // Get the current position (i.e., file size)
    fclose(fp);  // Close the file

    if (k > 0) {
        // If file size is greater than zero, the file has content
        return SUCCESS;
    } else {
        // If file size is zero, the file is empty
        printf("Content is not available in %s\n", argv);
        return FAILURE;
    }
}

// Function to check if a file is already present in the linked list (to prevent duplicates)
int check_duplicate(char *argv, Slist **head) {
    Slist *current = *head;  // Start at the head of the list

    // Traverse the list to look for the file name
    while (current != NULL) {
        // If the file name matches an existing entry, it's a duplicate
        if (strcmp(current->data, argv) == 0) {
            return FAILURE;
        }
        current = current->link;  // Move to the next node
    }

    // No duplicate found
    return SUCCESS;
}

// Function to add a new file name to the linked list
int add_list(char *argv, Slist **head) {
    // Allocate memory for a new node in the list
    Slist *new = malloc(sizeof(Slist));
    if (new == NULL) {
        // Allocation failed
        return FAILURE;
    }

    // Copy the file name into the new node
    strcpy(new->data, argv);
    new->link = NULL;  // Set the new node's link to NULL

    // If the list is currently empty, set the new node as the head
    if (*head == NULL) {
        *head = new;
    } else {
        // Traverse to the end of the list
        Slist *temp = *head;
        while (temp->link != NULL) {
            temp = temp->link;
        }
        // Link the last node to the new node
        temp->link = new;
    }
    return SUCCESS;  // Successfully added the file name to the list
}

