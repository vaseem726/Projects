#include<stdio.h>
#include "sll.h"

// Function to display the contents of the hash map
int display(hash *arr) {

    // Loop through each index in the hash array (28 indices for a-z, numbers, special characters)
    for (int i = 0; i < 28; i++) {
        
        // Check if there is a main linked list entry at the current index
        if (arr[i].h_link != NULL) {
            // Initialize a pointer to traverse the main linked list at this index
            Main *temp = arr[i].h_link;

            // Traverse each entry in the main linked list
            while (temp != NULL) {
                
                // Print the main word and the count of files containing this word
                printf("Main_word : %s, main_file_count : %d\n", temp->word, temp->file_count);

                // Initialize a pointer to traverse the sub-list for each word
                Sub *t = temp->Msub_link;

                // Traverse each file entry for this word
                while (t != NULL) {
                    // Print the file name and the count of occurrences of the word in this file
                    printf("file_name: %s, word_count: %d\n", t->file_name, t->word_count);

                    // Move to the next file in the sub-list
                    t = t->sub_link;
                }

                // Move to the next word in the main linked list
                temp = temp->main_link;
            }
        }
    }
}

