#include<stdio.h>
#include<string.h>
#include "sll.h"

// Function to search for a specific word in the hash map
int Search_Word(hash *arr, char *word) {

    // Calculate the index in the hash array based on the first character of the word
    // Subtracting 'a' (ASCII 97) from the first character to get index (0 for 'a', 1 for 'b', etc.)
    int i = word[0] - 97;

    // Check if there is an entry in the hash map at the calculated index
    if (arr[i].h_link != NULL) {
        // Initialize a temporary pointer to traverse the main linked list at this index
        Main *temp = arr[i].h_link;

        // Traverse through the main linked list to search for the word
        while (temp != NULL) {
            // Compare the word at the current node with the target word
            if (strcmp(temp->word, word) == 0) {
                // If the word is found, return SUCCESS
                return SUCCESS;
            }
            // Move to the next node in the main linked list
            temp = temp->main_link;
        }
    }

    // If the word is not found, return FAILURE
    return FAILURE;
}

