#include<stdio.h>
#include<string.h>
#include "sll.h"

int main(int argc, char *argv[]) {
    // Check if there are enough arguments (expecting at least one file as an argument)
    if (argc <= 1) {
        printf("Not sufficient arguments\n");
        return 0;
    }

    // Initialize linked list head pointer and hash array for the database
    Slist *head = NULL;
    hash arr[28];  // Array with 28 indices for a-z, numbers, and special characters
    char copy[10][MAX];  // Array to store filenames for updates
    int c = 0;  // Count for updated files
    int l = 0;
    int choice;  // Variable for storing user menu choice
    int flag = 1;  // Flag to track if database is created
    int flag1 = 1;  // Flag to track if database is updated

    // Loop through each argument (filename) and validate it
    for (int i = 1; i < argc; i++) {
        if (Read_and_validate(argv[i], &head) == FAILURE) {
            printf("Read and Validate is failure: %s\n", argv[i]);
            return 0;  // Exit if any file fails validation
        }
    }
    printf("Read and Validate is success\n");

    // Initialize hash array, setting each entry's h_link to NULL
    for (int i = 0; i < 28; i++) {
        arr[i].h_link = NULL;
    }

    // Main loop for user interaction with options menu
    while (1) {
        printf("1.create database\n2.Display\n3.Search\n4.Save\n5.Update\n6.Exit\nEnter Your Choice : ");
        scanf("%d", &choice);

        // Perform actions based on user's choice
        switch (choice) {
            case 1:
                // Create the database from files if not already created
                if (flag == 1) {
                    if (create_hash_map(arr, &head) == SUCCESS) {
                        printf("Create Database is Success\n");
                        flag = 0;  // Set flag indicating database is created
                    } else {
                        printf("Create database is failure\n");
                    }
                } else {
                    printf("Create database already created\n");
                }
                break;

            case 2:
                // Display the current contents of the hash map
                display(arr);
                break;

            case 3:
                // Search for a word in the database
                char word[20];
                printf("Enter the word you want to Search: ");
                scanf("%s", word);
                if (Search_Word(arr, word) == FAILURE) {
                    printf("INFO : Failure\nList is empty or Data not found\n");
                } else {
                    printf("Data is found\n");
                }
                break;

            case 4:
                // Save the current database to a file
                char str[20];
                printf("Enter the File Name : ");
                scanf("%s", str);
                if (save(arr, str) == SUCCESS) {
                    printf("File saved Successfully\n");
                } else {
                    printf("File is not saved\n");
                }
                break;

            case 5:
                // Update the database if not already updated
	      if(flag==1) {
                if (flag1 == 1) {
                    char str1[MAX];
                    Slist *head = NULL;
                    printf("Enter saved file: ");
                    scanf("%s", str1);

                    // Attempt to update the database from the saved file
                    if (Update(arr, str1, copy, &c) == SUCCESS) {
                        printf("Update Successfully\n");
                        flag1 = 0;  // Set flag indicating database has been updated
                    } else {
                        printf("Update is failure\n");
                    }

                    // Re-validate all arguments (filenames) and update as needed
                    for (int i = 1; i < argc; i++) {
                        for (int j = 0; j < c; j++) {
                            // Check if argument filename matches any filename in `copy`
                            if (strcmp(argv[i], copy[j]) == 0) {
                                l = 1;
                                break;
                            }
                        }
                        // If no match was found, re-validate and add to the list
                        if (l == 0) {
                            if (Read_and_validate(argv[i], &head) == SUCCESS);
                        }
                        l = 0;
                    }
                } else {
                    printf("Database already updated in file\n");
                }
	    } else {
		    printf("After create database we didn't update\n");
           }
                break;

            case 6:
                // Exit the program successfully
                return SUCCESS;

            default:
                // Handle invalid input for choice
                printf("Invalid input\n");
        }
    }
}

