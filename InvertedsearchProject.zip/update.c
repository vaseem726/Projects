#include <stdio.h>
#include <string.h>
#include "sll.h"

// Function to update the hash table with data from a saved file
int Update(hash *arr, char *str1, char copy[][MAX], int *c) {
    // Open the file for reading
    FILE *fp = fopen(str1, "r");

    // Check if the file has a ".txt" extension
    if (strstr(str1, ".txt") == NULL) {
        printf("%s is not .txt extension\n", str1);
        return FAILURE;
    }

    // Check if the file opened successfully
    if (fp == NULL) {
        printf("%s is not opened\n", str1);
        return FAILURE;
    }

    // Read the first word to check if the file is saved in the expected format
    char f_Word[256];
    fscanf(fp, "%s", f_Word);

    // Move to the end of the file to confirm it ends with '#'
    fseek(fp, 0, SEEK_END);
    long m = ftell(fp);
    char endchar;
    fseek(fp, m - 3, SEEK_SET);  // Move 3 bytes back to read the last characters
    fread(&endchar, sizeof(char), 1, fp);

    // If the file does not begin or end with '#', it is considered an invalid saved file
    if (f_Word[0] != '#' || endchar != '#') {
        printf("This %s file is not saved file\n", str1);
        return FAILURE;
    }

    // Reset the file pointer to the start
    rewind(fp);

    // Variables to hold hash index, file count, and tokens for parsing
    int h = 1;
    char *token;
    int f = 0;

    // Process each line in the file
    while (fscanf(fp, "%s", f_Word) != EOF) {
        // Extract the hash index from the first token
        token = strtok(f_Word, "#;");
        int k = atoi(token);

        // Process each token within the line
        while (token != NULL) {
            // Process main entry if not yet initialized
            if (f == 0) {
                if (arr[k].h_link == NULL) {
                    // Allocate memory for the new main node
                    Main *new = malloc(sizeof(Main));
                    if (new == NULL) {
                        printf("Main Memory allocation failed\n");
                        return FAILURE;
                    }

                    // Process main word, file count, and sub entry information
                    token = strtok(NULL, "#;");
                    if (token == NULL) {
                        printf("Token is NULL\n");
                        return FAILURE;
                    }
                    strcpy(new->word, token);
                    token = strtok(NULL, "#;");
                    if (token == NULL) {
                        printf("Token is NULL\n");
                        return FAILURE;
                    }
                    h = atoi(token);
                    new->file_count = h;

                    // Allocate and initialize subnode
                    Sub *new1 = malloc(sizeof(Sub));
                    if (new1 == NULL) {
                        printf("Sub Memory allocation failed\n");
                        return FAILURE;
                    }
                    token = strtok(NULL, "#;");
                    if (token == NULL) {
                        printf("Token is NULL\n");
                        return FAILURE;
                    }
                    strcpy(copy[(*c)++], token);
                    strcpy(new1->file_name, token);
                    token = strtok(NULL, "#;");
                    if (token == NULL) {
                        printf("Token is NULL\n");
                        return FAILURE;
                    }
                    h = atoi(token);
                    new1->word_count = h;
                    new1->sub_link = NULL;
                    new->Msub_link = new1;
                    arr[k].h_link = new;
                    f = 1;  // Indicate main entry has been initialized

                } else {
                    // If main entry already exists, traverse to the last main node
                    Main *temp1 = arr[k].h_link;
                    while (temp1->main_link != NULL) {
                        temp1 = temp1->main_link;
                    }

                    // Create and initialize new main entry node
                    Main *new = malloc(sizeof(Main));
                    if (new == NULL) {
                        printf("Main Memory allocation failed\n");
                        return FAILURE;
                    }
                    token = strtok(NULL, "#;");
                    if (token == NULL) {
                        printf("Token is NULL\n");
                        break;
                    }
                    strcpy(new->word, token);
                    token = strtok(NULL, "#;");
                    if (token == NULL) {
                        printf("Token is NULL\n");
                        break;
                    }
                    h = atoi(token);
                    new->file_count = h;
                    new->main_link = NULL;

                    // Create and initialize new subnode
                    Sub *new1 = malloc(sizeof(Sub));
                    if (new1 == NULL) {
                        printf("Sub Memory allocation failed\n");
                        return FAILURE;
                    }
                    token = strtok(NULL, "#;");
                    if (token == NULL) {
                        printf("Token is NULL\n");
                        break;
                    }
                    strcpy(copy[(*c)++], token);
                    strcpy(new1->file_name, token);
                    token = strtok(NULL, "#;");
                    if (token == NULL) {
                        printf("Token is NULL\n");
                        break;
                    }
                    h = atoi(token);
                    new1->word_count = h;
                    new1->sub_link = NULL;
                    new->Msub_link = new1;
                    temp1->main_link = new;
                    f = 1;  // Indicate main entry has been initialized
                }
            }

            // If the file name has ".txt" and the main entry is initialized, process sub-entries
            if (f == 1) {
                if (strstr(token, ".txt") != NULL) {
                    // Traverse the subnode list to the last subnode
                    Sub *t = arr[k].h_link->Msub_link;
                    while (t->sub_link != NULL) {
                        t = t->sub_link;
                    }

                    // Create and initialize new subnode
                    Sub *new1 = malloc(sizeof(Sub));
                    if (new1 == NULL) {
                        printf("Sub Memory allocation failed\n");
                        return FAILURE;
                    }
                    strcpy(copy[(*c)++], token);
                    strcpy(new1->file_name, token);
                    token = strtok(NULL, "#;");
                    if (token == NULL) {
                        printf("Token is NULL\n");
                        break;
                    }
                    h = atoi(token);
                    new1->word_count = h;
                    new1->sub_link = NULL;
                    t->sub_link = new1;
                }
            }

            // Move to the next token in the current line
            token = strtok(NULL, "#;");
        }
        f = 0;  // Reset flag for the next line
    }

    // Close the file and return success
    fclose(fp);
    return SUCCESS;
}

