#include<stdio.h>
#include "sll.h"
#include<string.h>
#include<ctype.h>

// Function to create a hash map from a list of files, using a linked list structure.
int create_hash_map(hash *arr, Slist **head) {

    // Check if the linked list (head) is empty
    if (*head == NULL) {
        printf("List is Empty\n");
    }

    // Initialize temporary pointer to traverse the linked list
    Slist *temp = *head;

    // Loop through each file in the linked list
    while (temp != NULL) {
        // Open each file for reading
        FILE *fp = fopen(temp->data, "r");
        if (fp == NULL) {
            printf("File is Empty\n");
            return FAILURE;
        }

        int index, k;
        char Word[20];

        // Read each word from the file until the end of the file
        while (fscanf(fp, "%s", Word) != EOF) {
            // Determine hash index based on the first character of the word

            if (Word[0] >= '0' && Word[0] <= '9') {
                // Index 26 for words starting with numbers
                index = 26;
            } else if (Word[0] >= 'a' && Word[0] <= 'z') {
                // Calculate index for lowercase letters ('a' to 'z')
                index = Word[0] - 'a';
            } else if (Word[0] >= 'A' && Word[0] <= 'Z') {
                // Convert uppercase letter to lowercase for consistency and calculate index
                char lower = tolower(Word[0]);
                index = lower - 'a';
            } else {
                // Index 27 for words starting with special characters
                index = 27;
            }

            // Check if hash bucket at index is empty
            if (arr[index].h_link == NULL) {
                // Create a new main node and sub-node since this is a new word for this index
                Main *new = malloc(sizeof(Main));
                strcpy(new->word, Word);
                new->file_count = 1;
                new->main_link = NULL;

                // Initialize sub-node with filename and word count
                Sub *new1 = malloc(sizeof(Sub));
                strcpy(new1->file_name, temp->data);
                new1->word_count = 1;
                new1->sub_link = NULL;

                // Link sub-node to main node and set hash array's link
                new->Msub_link = new1;
                arr[index].h_link = new;
            } else {
                // If there are existing entries at this index, look for the word
                Main *temp1 = arr[index].h_link;
                Main *previ;
                int f = 0;  // Flag to check if word was found

                // Traverse the main linked list for this index
                while (temp1 != NULL) {
                    previ = temp1;

                    // Check if the word already exists
                    if (strcmp(temp1->word, Word) == 0) {
                        f = 1;  // Set flag indicating word is found
                        Sub *t = temp1->Msub_link;
                        Sub *previ1;
                        int flag = 0;  // Flag for file check

                        // Traverse sub-nodes to see if word exists in the current file
                        while (t != NULL) {
                            previ1 = t;
                            if (strcmp(t->file_name, temp->data) == 0) {
                                t->word_count++;  // Increment word count if file matches
                                flag = 1;
                                break;
                            }
                            t = t->sub_link;
                        }

                        // If word exists but file not found, add a new sub-node for this file
                        if (flag == 0) {
                            Sub *new1 = malloc(sizeof(Sub));
                            strcpy(new1->file_name, temp->data);
                            new1->word_count = 1;
                            new1->sub_link = NULL;
                            previ1->sub_link = new1;  // Link new sub-node
                            temp1->file_count++;  // Increment file count for the word
                        }
                    }
                    temp1 = temp1->main_link;
                }

                // If word does not exist, create a new main node and sub-node
                if (f == 0) {
                    Main *new = malloc(sizeof(Main));
                    strcpy(new->word, Word);
                    new->file_count = 1;
                    new->main_link = NULL;

                    // Create new sub-node for the file
                    Sub *new1 = malloc(sizeof(Sub));
                    strcpy(new1->file_name, temp->data);
                    new1->word_count = 1;
                    new1->sub_link = NULL;

                    // Link new sub-node and set previous main node's link
                    new->Msub_link = new1;
                    previ->main_link = new;
                }
            }
        }

        // Move to the next file in the linked list
        temp = temp->link;
    }
    return SUCCESS;  // Return success status
}

