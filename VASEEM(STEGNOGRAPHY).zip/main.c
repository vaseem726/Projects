#include <stdio.h>           // Include standard input-output library
#include "encode.h"         // Include the header file for encoding functions
#include "decode.h"         // Include the header file for decoding functions
#include "types.h"          // Include the header file for type definitions

int main(int argc, char *argv[]) { // Main function with command-line arguments
    if(argc < 3) { // Check if there are fewer than 3 arguments
        printf("Error:- Insufficient Arguments\n"); // Print error message
        printf("Usage:- \nfor encoding ->./a.out -e <.bmp file> <secret.file>\nfor decoding ->./a.out -d <.bmp file> <secret.file>\n"); // Print usage instructions
        return e_failure; // Return failure status
    }
    else if(argc >= 3 && check_operation_type(argv) == e_decode) { // Check if the operation is decoding
        DecodeInfo decInfo; // Declare a variable for decoding information
        printf("Decoding is starting\n"); // Indicate that decoding is starting
        char str[100] = "vaseem"; // Initialize a string (could be used for a password or key)
        
        if(read_and_validate_decode_args(argv, &decInfo, str) == e_success) { // Validate decoding arguments
            printf("Read and validate the data\n"); // Indicate successful validation
            
            if (do_decoding(&decInfo) == e_success) { // Perform decoding
                printf("Decoding is completed successfully\n"); // Indicate successful decoding
            } else {
                printf("Decoding is failure\n"); // Indicate failure in decoding
            }
        }
    }
    else if(argc >= 4 && check_operation_type(argv) == e_encode) { // Check if the operation is encoding
        EncodeInfo encInfo; // Declare a variable for encoding information
        printf("Encoding is starting\n"); // Indicate that encoding is starting
        
        if(read_and_validate_encode_args(argv, &encInfo) == e_success) { // Validate encoding arguments
            printf("Read and validate the data\n"); // Indicate successful validation
            
            if (do_encoding(&encInfo) == e_success) { // Perform encoding
                printf("Encoding is completed successfully\n"); // Indicate successful encoding
            } else {
                printf("Encoding is failure\n"); // Indicate failure in encoding
            }
        }
    } else { // If none of the above conditions are met
        printf("Error:- Insufficient Arguments\n"); // Print error message
        printf("Usage:- \nfor encoding ->./a.out -e <.bmp file> <secret.file>\nfor decoding ->./a.out -d <.bmp file> <secret.file>\n"); // Print usage instructions
        return e_failure; // Return failure status
    }

    return 0; // Return success status
}

