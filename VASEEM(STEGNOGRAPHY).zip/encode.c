#include <stdio.h>           // Include standard I/O library for file operations
#include <string.h>         // Include string library for string manipulation
#include "encode.h"         // Include custom header for encoding functions and definitions
#include "types.h"          // Include custom header for type definitions
#include "common.h"         // Include custom header for common functions and constants

// Function to check the operation type based on command-line arguments
OperationType check_operation_type(char *argv[]) {
    // Compare the second argument with "-e" for encoding
    if (strcmp(argv[1], "-e") == 0)
        return e_encode;    // Return encoding operation type
    // Compare the second argument with "-d" for decoding
    else if (strcmp(argv[1], "-d") == 0)
        return e_decode;    // Return decoding operation type
    return e_unsupported;   // Return unsupported operation type if none matches
}

// Function to read and validate arguments for encoding
Status read_and_validate_encode_args(char *argv[], EncodeInfo *encInfo) {
    // Check if the second argument is a .bmp file
    if (strstr(argv[2], ".bmp") != NULL) {
        encInfo->src_image_fname = argv[2];  // Set the source image filename

        // Check if the third argument is a valid secret file type
        if ((strstr(argv[3], ".c") != NULL) || (strstr(argv[3], ".txt") != NULL) || (strstr(argv[3], ".sh") != NULL)) {
            encInfo->secret_fname = argv[3];  // Set the secret filename
            strcpy(encInfo->extn_secret_file, strstr(argv[3], "."));  // Copy the extension of the secret file
            
            // Check if the fourth argument is provided
            if (argv[4] == NULL) {
                encInfo->stego_image_fname = "Stego.bmp";  // Default stego image filename
                return e_success;  // Return success
            } else {
                // Check if the fourth argument is a .bmp file
                if (strstr(argv[4], ".bmp") != NULL) {
                    encInfo->stego_image_fname = argv[4];  // Set the stego image filename
                    return e_success;  // Return success
                } else {
                    printf("Error: stego file is not validate\n");  // Print error message
                    return e_failure;  // Return failure
                }
            }
        } else {
            printf("Error: txt file is not validate\n");  // Print error message if secret file is invalid
            return e_failure;  // Return failure
        }
    } else {
        printf("Error: bmp file is not validate\n");  // Print error message if source image is invalid
        return e_failure;  // Return failure
    }
}

// Function to get the size of a file
uint get_file_size(FILE *fptr) {
    fseek(fptr, 0, SEEK_END);  // Move the file pointer to the end of the file
    return ftell(fptr);  // Return the current position, which is the file size
}

// Function to check if the source image has enough capacity to hold the encoded data
Status check_capacity(EncodeInfo *encInfo) {
    uint Image_size = get_image_size_for_bmp(encInfo->fptr_src_image);  // Get the size of the BMP image
    // Calculate the size required for encoding the secret data
    int file_size = get_file_size(encInfo->fptr_secret);  // Get the size of the secret file
    int encode_size = 54 + ((strlen(MAGIC_STRING) + 4 + strlen(encInfo->extn_secret_file) + 4 + file_size) * 8);
    // Check if the image size is greater than the encoding size
    if (Image_size > encode_size) {
        return e_success;  // Return success if capacity is sufficient
    }
    return e_failure;  // Return failure if capacity is insufficient
}

// Function to copy the BMP header from the source image to the destination image
Status copy_bmp_header(FILE *fptr_src_image, FILE *fptr_dest_image) {
    char buffer[54];  // Buffer to hold the BMP header (54 bytes)
    fseek(fptr_src_image, 0, SEEK_SET);  // Move to the start of the source image
    fread(buffer, 54, 1, fptr_src_image);  // Read the BMP header
    fwrite(buffer, 54, 1, fptr_dest_image);  // Write the BMP header to the destination image
    return e_success;  // Return success
}

// Function to encode a byte of data into the least significant bit of an image buffer
Status encode_byte_to_lsb(char data, char *image_buffer) {
    for (int i = 0; i < 8; i++) {  // Loop through each bit of the byte
        image_buffer[i] = (image_buffer[i] & 0xFE) | ((data & (1 << i)) >> i);  // Modify the least significant bit
    }
    return e_success;  // Return success
}

// Function to encode data into the stego image
Status encode_data_to_image(char *data, int size, FILE *fptr_src_image, FILE *fptr_stego_image) {
    char Image_buffer[8];  // Buffer to hold 8 bits of the image
    for (int i = 0; i < size; i++) {  // Loop through each byte of data
        fread(Image_buffer, 8, 1, fptr_src_image);  // Read 8 bits from the source image
        if (encode_byte_to_lsb(data[i], Image_buffer) == e_success) {  // Encode the byte into the image buffer
            fwrite(Image_buffer, 8, 1, fptr_stego_image);  // Write the modified image buffer to the stego image
        } else {
            e_failure;  // Return failure if encoding fails
        }
    }
    return e_success;  // Return success
}

// Function to encode a magic string into the stego image
Status encode_magic_string(char *magic_string, EncodeInfo *encInfo) {
    if (encode_data_to_image(magic_string, strlen(magic_string), encInfo->fptr_src_image, encInfo->fptr_stego_image) == e_success) {
        return e_success;  // Return success if encoding magic string is successful
    } else {
        return e_failure;  // Return failure if encoding magic string fails
    }
}

// Function to encode the length of the secret file extension into the image
Status encode_secret_file_extn_size(char *file_ext, EncodeInfo *encInfo) {
    char Image_buffer[32];  // Buffer to hold 32 bits for the extension size
    fread(Image_buffer, 32, 1, encInfo->fptr_src_image);  // Read 32 bits from the source image
    encode_size_to_lsb(strlen(file_ext), Image_buffer);  // Encode the size of the file extension
    fwrite(Image_buffer, 32, 1, encInfo->fptr_stego_image);  // Write the modified buffer to the stego image
    return e_success;  // Return success
}

// Function to encode an integer size into the least significant bits of an image buffer
Status encode_size_to_lsb(int size, char *image_buffer) {
    for (int i = 0; i < 32; i++) {  // Loop through each bit of the integer size
        image_buffer[i] = (image_buffer[i] & 0xFE) | ((size & (1 << i)) >> i);  // Modify the least significant bit
    }
    return e_success;  // Return success
}

// Function to encode the secret file extension into the stego image
Status encode_secret_file_extn(char *file_extn, EncodeInfo *encInfo) {
    encode_data_to_image(file_extn, strlen(file_extn), encInfo->fptr_src_image, encInfo->fptr_stego_image);  // Encode the extension
    return e_success;  // Return success
}

// Function to encode the size of the secret file into the image
Status encode_secret_file_size(long file_size, EncodeInfo *encInfo) {
    char Image_buffer[32];  // Buffer to hold 32 bits for the file size
    fread(Image_buffer, 32, 1, encInfo->fptr_src_image);  // Read 32 bits from the source image
    encode_size_to_lsb(file_size, Image_buffer);  // Encode the file size
    fwrite(Image_buffer, 32, 1, encInfo->fptr_stego_image);  // Write the modified buffer to the stego image
    return e_success;  // Return success
}

// Function to encode the actual secret file data into the stego image
Status encode_secret_file_data(EncodeInfo *encInfo) {
    unsigned int size = get_file_size(encInfo->fptr_secret);  // Get the size of the secret file
    rewind(encInfo->fptr_secret);  // Rewind the secret file pointer to the start
    printf("data size: %d\n", size);  // Print the size of the data
    char data[size];  // Allocate buffer for the data
    fread(data, size, 1, encInfo->fptr_secret);  // Read the secret file data into the buffer
    printf("%s", data);  // Print the data read from the secret file
    encode_data_to_image(data, size, encInfo->fptr_src_image, encInfo->fptr_stego_image);  // Encode the data into the stego image
    return e_success;  // Return success
}

// Function to copy the remaining image data from the source to the stego image
Status copy_remaining_img_data(FILE *fptr_src, FILE *fptr_dest) {
    printf("dest image eof : %ld\n", ftell(fptr_dest));  // Print the end-of-file position of the destination image
    long int k = ftell(fptr_src);  // Get the current position in the source image
    printf("%ld\n", k);  // Print the current position in the source image

    int byte;  // Variable to hold the byte read from the source image
    // Read and copy bytes until the end of the source file
    while ((byte = fgetc(fptr_src)) != EOF) {
        fputc(byte, fptr_dest);  // Write the byte to the destination image
    }

    printf("src image size : %ld\n", ftell(fptr_src));  // Print the size of the source image
    printf("dest image eof : %ld\n", ftell(fptr_dest));  // Print the end-of-file position of the destination image
    return e_success;  // Return success
}

// Function to get the size of the BMP image based on its width and height
uint get_image_size_for_bmp(FILE *fptr_image) {
    uint width, height;  // Variables to hold the width and height
    fseek(fptr_image, 18, SEEK_SET);  // Seek to the width (stored at offset 18)
    fread(&width, sizeof(int), 1, fptr_image);  // Read the width of the image
    printf("width = %u\n", width);  // Print the width

    fseek(fptr_image, 22, SEEK_SET);  // Seek to the height (stored at offset 22)
    fread(&height, sizeof(int), 1, fptr_image);  // Read the height of the image
    printf("height = %u\n", height);  // Print the height

    // Return the image size (width * height * bytes per pixel)
    return width * height * 3;
}

// Function to handle the encoding process
Status do_encoding(EncodeInfo *encInfo) {
    if (open_files(encInfo) == e_success) {  // Open the necessary files
        printf("opening_files successfully\n");
        if (check_capacity(encInfo) == e_success) {  // Check if there is enough capacity
            printf("check_capacity successfully\n");
            if (copy_bmp_header(encInfo->fptr_src_image, encInfo->fptr_stego_image) == e_success) {  // Copy the BMP header
                printf("copy_bmp_header successfully\n");
                if (encode_magic_string(MAGIC_STRING, encInfo) == e_success) {  // Encode the magic string
                    printf("encode_magic_string successfully\n");
                    if (encode_secret_file_extn_size(encInfo->extn_secret_file, encInfo) == e_success) {  // Encode the extension size
                        printf("encode_secret_file_extn_size successfully\n");
                        if (encode_secret_file_extn(strstr(encInfo->secret_fname, "."), encInfo) == e_success) {  // Encode the extension
                            printf("encode_secret_file_extn successfully\n");
                            if (encode_secret_file_size(get_file_size(encInfo->fptr_secret), encInfo) == e_success) {  // Encode the file size
                                printf("encode_secret_file_size successfully\n");
                                if (encode_secret_file_data(encInfo) == e_success) {  // Encode the secret file data
                                    printf("encode_secret_file_data\n");
                                    if (copy_remaining_img_data(encInfo->fptr_src_image, encInfo->fptr_stego_image) == e_success) {  // Copy remaining data
                                        printf("copy_remaining_img_data successfully\n");
                                        return e_success;  // Return success after all operations
                                    } else {
                                        printf("copy_remaining_img_data failure\n");  // Print failure message
                                        return e_failure;  // Return failure
                                    }
                                } else {
                                    printf("encode_secret_file_data failure\n");  // Print failure message
                                    return e_failure;  // Return failure
                                }
                            } else {
                                printf("encode_secret_file_size failure\n");  // Print failure message
                                return e_failure;  // Return failure
                            }
                        } else {
                            printf("encode_secret_file_extn failure\n");  // Print failure message
                            return e_failure;  // Return failure
                        }
                    } else {
                        printf("encode_secret_file_extn_size failure\n");  // Print failure message
                        return e_failure;  // Return failure
                    }
                } else {
                    printf("encode_magic_string failure\n");  // Print failure message
                    return e_failure;  // Return failure
                }
            }
            printf("copy_bmp_header failure\n");  // Print failure message
            return e_failure;  // Return failure
        }
        printf("check_capacity failure\n");  // Print failure message
        return e_failure;  // Return failure
    } else {
        printf("opening_files failure\n");  // Print failure message
        return e_failure;  // Return failure
    }
}

// Function to open files for reading and writing
Status open_files(EncodeInfo *encInfo) {
    // Open the source image file for reading
    encInfo->fptr_src_image = fopen(encInfo->src_image_fname, "r");
    // Check for file opening errors
    if (encInfo->fptr_src_image == NULL) {
        perror("fopen");  // Print error message
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->src_image_fname);  // Print error message
        return e_failure;  // Return failure
    }

    // Open the secret file for reading
    encInfo->fptr_secret = fopen(encInfo->secret_fname, "r");
    // Check for file opening errors
    if (encInfo->fptr_secret == NULL) {
        perror("fopen");  // Print error message
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->secret_fname);  // Print error message
        return e_failure;  // Return failure
    }

    // Open the stego image file for writing
    encInfo->fptr_stego_image = fopen(encInfo->stego_image_fname, "w");
    // Check for file opening errors
    if (encInfo->fptr_stego_image == NULL) {
        perror("fopen");  // Print error message
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->stego_image_fname);  // Print error message
        return e_failure;  // Return failure
    }

    // If no failures occur, return success
    return e_success;
}

