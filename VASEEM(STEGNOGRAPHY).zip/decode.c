#include <stdio.h>           // Include standard I/O library for input and output functions
#include <string.h>         // Include string library for string manipulation functions
#include "decode.h"         // Include custom header for decode-related declarations
#include "types.h"          // Include custom header for type definitions
#include "common.h"         // Include common header for shared functionalities

// Function to read and validate decoding arguments from command line
Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo, char *str) {
    // Check if the third command line argument has a .bmp extension
    if (strstr(argv[2], ".bmp") != NULL) {
        decInfo->src_image_fname = argv[2]; // Store the source image filename

        char *file = argv[3]; // Get the next command line argument
        // Check if the argument is NULL
        if (argv[3] == NULL) {
            decInfo->secret_fname = str; // Set secret filename from passed string
            printf("%s\n", decInfo->secret_fname); // Print the secret filename
            return e_success; // Return success status
        }
        // Check if the argument has .txt, .c, or .sh extension
        else if ((strstr(argv[3], ".txt") != NULL) || (strstr(argv[3], ".c") != NULL) || (strstr(argv[3], ".sh") != NULL)) {
            decInfo->secret_fname = strtok(argv[3], "."); // Set secret filename without extension
            return e_success; // Return success status
        } else {
            printf(".txt file is not valid\n"); // Print error message for invalid file
            return e_failure; // Return failure status
        }
    } else {
        printf("bmp file is not valid\n"); // Print error message for invalid bmp file
        return e_failure; // Return failure status
    }
    return e_success; // Default return success status
}

// Function to decode a byte by reading its least significant bits from the image buffer
Status decode_byte_to_lsb(char data, char *image_buffer) {
    int decode = 0; // Variable to hold the decoded value
    // Loop through 8 bits to construct the decoded byte
    for (int i = 0; i < 8; i++) {
        decode |= ((image_buffer[i] & 1) << i); // Extract the LSB and shift it into place
    }
    // Print the decoded character and the original data byte
    printf("%c %c\n", decode, data);
    // Compare the decoded byte with the original data
    if (decode == data) {
        return e_success; // Return success if they match
    } else {
        return e_failure; // Return failure if they don't match
    }
}

// Function to decode a specified amount of data into the image buffer
Status decode_data_to_image(char *data, int size, FILE *fptr_src_image) {
    char Image_buffer[8]; // Buffer to hold image data
    // Loop through each byte to be decoded
    for (int i = 0; i < size; i++) {
        fread(Image_buffer, 8, 1, fptr_src_image); // Read 8 bits from the image file
        // Decode the byte and check if successful
        if (decode_byte_to_lsb(data[i], Image_buffer) == e_success) {
            printf("byte success\n"); // Print success message for byte decoding
        } else {
            return e_failure; // Return failure status if decoding fails
        }
    }
    return e_success; // Return success if all bytes decoded
}

// Function to decode the magic string from the source image
Status decode_magic_string(char *magic_string, DecodeInfo *decInfo) {
    char buffer[16]; // Buffer to hold read data
    fseek(decInfo->fptr_src_image, 54, SEEK_SET); // Seek to the position after BMP header
    printf("position : %ld\n", ftell(decInfo->fptr_src_image)); // Print current file position
    // If decoding magic string is successful
    if (decode_data_to_image(magic_string, strlen(magic_string), decInfo->fptr_src_image) == e_success) {
        printf("magic string : %ld\n", ftell(decInfo->fptr_src_image)); // Print position after decoding
        return e_success; // Return success status
    }
    return e_failure; // Return failure if decoding fails
}

// Function to decode the size of the secret file from the image buffer
Status decode_size_to_lsb(char *image_buffer, DecodeInfo *decInfo) {
    int decode = 0; // Variable to hold the decoded size
    // Loop through 32 bits to construct the decoded size
    for (int i = 0; i < 32; i++) {
        decode |= ((image_buffer[i] & 1) << i); // Extract the LSB and shift it into place
    }
    printf("extension decoding : %d\n", decode); // Print the decoded size
    decInfo->size_secret_file = decode; // Store the size in DecodeInfo structure
    return e_success; // Return success status
}

// Function to decode the size of the secret file extension
Status decode_secret_file_extn_size(DecodeInfo *decInfo) {
    char Image_buffer[32]; // Buffer to hold size data
    fread(Image_buffer, 32, 1, decInfo->fptr_src_image); // Read 32 bits from image file
    // If size decoding is successful
    if (decode_size_to_lsb(Image_buffer, decInfo) == e_success) {
        printf("extn file size : %ld\n", ftell(decInfo->fptr_src_image)); // Print position after reading
        return e_success; // Return success status
    }
    return e_failure; // Return failure if decoding fails
}

// Function to decode the extension of the secret file
Status decode_secret_file_extn(DecodeInfo *decInfo) {
    char Image_buffer[32]; // Buffer to hold read data
    int k; // Variable to hold calculated size
    int l = 0; // Index for string construction
    char str[20]; // Buffer to hold the file extension string
    k = decInfo->size_secret_file; // Get the size from DecodeInfo
    // Adjust size based on expected size
    if (decInfo->size_secret_file == 4) {
        k = 32; // Use 32 bits for size 4
    } else if (decInfo->size_secret_file == 3) {
        k = 24; // Use 24 bits for size 3
    } else if (decInfo->size_secret_file == 2) {
        k = 16; // Use 16 bits for size 2
    }
    fread(Image_buffer, k, 1, decInfo->fptr_src_image); // Read the calculated size
    int decode = 0; // Variable to hold decoded character
    // Loop through the read data to decode characters
    for (int i = 0; i < k; i = i + 8) {
        for (int j = 0; j < 8; j++) {
            decode |= ((Image_buffer[i + j] & 1) << j); // Extract and shift each bit
        }
        str[l++] = decode; // Store decoded character in string
        decode = 0; // Reset decode for next character
    }
    str[l] = '\0'; // Null-terminate the string
    printf(".txt:%s\n", str); // Print the decoded file extension
    printf("extn file position : %ld\n", ftell(decInfo->fptr_src_image)); // Print current file position
    char *src = str; // Pointer to the decoded extension
    strcat(decInfo->secret_fname, src); // Append extension to secret filename
    printf("secret file name: %s\n", decInfo->secret_fname); // Print the complete secret filename
    decInfo->fptr_secret = fopen(decInfo->secret_fname, "w"); // Open secret file for writing
    return e_success; // Return success status
}

// Function to decode the size of the secret file
Status decode_secret_file_size(DecodeInfo *decInfo) {
    char Image_buffer[32]; // Buffer to hold size data
    fread(Image_buffer, 32, 1, decInfo->fptr_src_image); // Read 32 bits from image file
    // If size decoding is successful
    if (decode_size_to_lsb(Image_buffer, decInfo) == e_success) {
        printf("secret file size : %ld\n", ftell(decInfo->fptr_src_image)); // Print position after reading
        return e_success; // Return success status
    }
    return e_failure; // Return failure if decoding fails
}

// Function to decode the actual secret file data
Status decode_secret_file_data(DecodeInfo *decInfo) {
    char Image_buffer[decInfo->size_secret_file * 8]; // Buffer to hold read data
    int k = decInfo->size_secret_file * 8; // Calculate the number of bits to read
    int l = 0; // Index for string construction
    char str[decInfo->size_secret_file]; // Buffer to hold the decoded message
    fread(Image_buffer, k, 1, decInfo->fptr_src_image); // Read the calculated size
    int decode = 0; // Variable to hold decoded character
    // Loop through the read data to decode characters
    for (int i = 0; i < k; i = i + 8) {
        for (int j = 0; j < 8; j++) {
            decode |= ((Image_buffer[i + j] & 1) << j); // Extract and shift each bit
        }
        str[l++] = decode; // Store decoded character in string
        decode = 0; // Reset decode for next character
    }
    str[l] = '\0'; // Null-terminate the string
    printf("Message:%s\n", str); // Print the decoded secret message
    printf("final position : %ld\n", ftell(decInfo->fptr_src_image)); // Print current file position
    rewind(decInfo->fptr_secret); // Rewind secret file pointer to the beginning
    fprintf(decInfo->fptr_secret, "%s\n", str); // Write the decoded message to the secret file
    fclose(decInfo->fptr_secret); // Close the secret file
    return e_success; // Return success status
}

// Function to perform the overall decoding process
Status do_decoding(DecodeInfo *decInfo) {
    // Open necessary files for decoding
    if (open_files_decode(decInfo) == e_success) {
        printf("opening_files successfully\n"); // Print success message for file opening
        // Decode the magic string
        if (decode_magic_string(MAGIC_STRING, decInfo) == e_success) {
            printf("Magic string decoded\n"); // Print success message for magic string decoding
            // Decode the secret file extension size
            if (decode_secret_file_extn_size(decInfo) == e_success) {
                printf("Secret file extension is decoded\n"); // Print success message for extension size
                // Decode the secret file extension
                if (decode_secret_file_extn(decInfo) == e_success) {
                    printf("decode_secret_file_extn successfully\n"); // Print success message for extension decoding
                    // Decode the size of the secret file
                    if (decode_secret_file_size(decInfo) == e_success) {
                        printf("decode_secret_file_size successfully\n"); // Print success message for size decoding
                        // Decode the actual secret file data
                        if (decode_secret_file_data(decInfo) == e_success) {
                            return e_success; // Return success if all steps completed
                        }
                    }
                }
            }
        }
    }
    return e_failure; // Return failure if any step fails
}

// Function to open the files required for decoding
Status open_files_decode(DecodeInfo *decInfo) {
    // Open the source image file for reading
    decInfo->fptr_src_image = fopen(decInfo->src_image_fname, "r");
    // Check if the source image file opened successfully
    if (decInfo->fptr_src_image == NULL) {
        perror("fopen"); // Print error for file opening
        fprintf(stderr, "ERROR: Unable to open file %s\n", decInfo->src_image_fname); // Print error message
        return e_failure; // Return failure status
    }

    // The secret file is opened in write mode later in decode_secret_file_extn function

    // Return success if no failure occurred
    return e_success; 
}

