#include <stdio.h>
#include "file.h"
#include "contact.h"

void saveContactsToFile(AddressBook *addressBook) {
	FILE *fp=fopen("addressbookfile.csv", "w");
	 if (fp == NULL) {
        printf("Error: Could not open file for writing.\n");
        return;
    }

	int n=addressBook->contactCount;
	fprintf(fp, "%d\n", addressBook->contactCount);
	for(int i=0;i<n;i++) {
		fprintf(fp,"%s,%s,%s\n",addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
	}
	fclose(fp);
  
}


void loadContactsFromFile(AddressBook *addressBook)
{
    Contact details;
    if (addressBook == NULL) {
        fprintf(stderr, "Error: AddressBook pointer is NULL.\n");
        return;
    }

    FILE *ptr = fopen("addressbookfile.csv", "r");
    if (ptr == NULL) {
        printf("Error opening file");
        return;
    }
    fscanf(ptr,"%d\n",&addressBook->contactCount);
     printf("Total number of contacts are %d\n",addressBook->contactCount);
   // addressBook->contactCount=0;
    while (fscanf(ptr, "%[^,],%[^,],%[^\n]\n",details.name,details.phone,details.email) == 3)
    {

        if (addressBook->contactCount >= MAX_CONTACTS) {
            printf("Warning: Maximum number of contacts reached.\n");
            break;
        }


        addressBook->contacts[addressBook->contactCount++] = details;
    }

    // Check for reading errors (other than end-of-file)
    if (ferror(ptr)) {
        perror("Error reading file");
    }

    fclose(ptr);
   // printf("Number of contacts loaded: %d\n", addressBook->contactCount);
}
              


