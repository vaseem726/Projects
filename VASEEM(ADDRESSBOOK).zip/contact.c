#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "contact.h"
#include "file.h"
#include "populate.h"

void listContacts(AddressBook *addressBook)
{
	int n=addressBook->contactCount;
	Contact temp;
	printf("+-------------------------------------+-----------------+---------------------------------------+\n");
	printf("| %-35s | %-15s | %-37s |\n", "Name", "Phone Number", "Email");
	printf("+-------------------------------------+-----------------+---------------------------------------+\n");
	for(int i=0;i<n;i++) {
		printf("| %-35s | %-15s | %-37s |\n", addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
		printf("+-------------------------------------+-----------------+---------------------------------------+\n");
	}
	printf("list count: %d\n",addressBook->contactCount);
	int k;
	printf("Display the Contacts in Sorting order\n");
	printf("1.Name\n2.Mobile\n3.Email\n4.No sorting\n");
	printf("If you want to sort select one option\n");
	scanf("%d", &k);
	if(k==1) {
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<n-i-1;j++) {
				if(strcmp(addressBook->contacts[j].name,addressBook->contacts[j+1].name)>0) {
					temp=addressBook->contacts[j];
					addressBook->contacts[j]=addressBook->contacts[j+1];
					addressBook->contacts[j+1]=temp;
				}

			}


		}
		printf("+-------------------------------------+-----------------+---------------------------------------+\n");
		printf("| %-35s | %-15s | %-37s |\n", "Name", "Phone Number", "Email");
		printf("+-------------------------------------+-----------------+---------------------------------------+\n");
		for(int i=0;i<n;i++) {

			printf("| %-35s | %-15s | %-37s |\n", addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
			printf("+-------------------------------------+-----------------+---------------------------------------+\n");
		}
	}
	if(k==2) {
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<n-i-1;j++) {
				if(strcmp(addressBook->contacts[j].phone,addressBook->contacts[j+1].phone)>0) {
					temp=addressBook->contacts[j];
					addressBook->contacts[j]=addressBook->contacts[j+1];
					addressBook->contacts[j+1]=temp;
				}

			}


		}
		printf("+-------------------------------------+-----------------+---------------------------------------+\n");
		printf("| %-35s | %-15s | %-37s |\n", "Name", "Phone Number", "Email");
		printf("+-------------------------------------+-----------------+---------------------------------------+\n");
		for(int i=0;i<n;i++) {
			printf("| %-35s | %-15s | %-37s |\n", addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
			printf("+-------------------------------------+-----------------+---------------------------------------+\n");
		}
	}
	if(k==3) {
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<n-i-1;j++) {
				if(strcmp(addressBook->contacts[j].email,addressBook->contacts[j+1].email)>0) {
					temp=addressBook->contacts[j];
					addressBook->contacts[j]=addressBook->contacts[j+1];
					addressBook->contacts[j+1]=temp;


				}
			} 
		} 
		printf("+-------------------------------------+-----------------+---------------------------------------+\n");
		printf("| %-35s | %-15s | %-37s |\n", "Name", "Phone Number", "Email");
		printf("+-------------------------------------+-----------------+---------------------------------------+\n");
		for(int i=0;i<n;i++) {
			printf("| %-35s | %-15s | %-37s |\n", addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
			printf("+-------------------------------------+-----------------+---------------------------------------+\n");
		}
	}
	if(k==0) {
		return;
	}

}

void initialize(AddressBook *addressBook) {
	populateAddressBook(addressBook);
	int n=addressBook->contactCount;
	printf("+-------------------------------------+-----------------+---------------------------------------+\n");
	printf("| %-35s | %-15s | %-37s |\n", "Name", "Phone Number", "Email");
	printf("+-------------------------------------+-----------------+---------------------------------------+\n");
	for(int i=0;i<n;i++) {
		printf("| %-35s | %-15s | %-37s |\n", addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
		printf("+-------------------------------------+-----------------+---------------------------------------+\n");
		//addressBook->contactCount++;
	}



	// Load contacts from file during initialization (After files)
	loadContactsFromFile(addressBook);
}

void saveAndExit(AddressBook *addressBook) {
	saveContactsToFile(addressBook); // Save contacts to file
	exit(EXIT_SUCCESS); // Exit the program
}
char validateName(char *str, AddressBook *addressBook) {
	int k=1,valid=1;
	while(k) {
		valid=1;
		printf("Enter Name: ");
		scanf(" %[^\n]",str);
		getchar();
		for(int i=0; str[i]!='\0';i++) {
			if(!(str[i]>='a' && str[i]<='z' || str[i] >='A' && str[i]<='Z' || str[i]=='.' || str[i]==' ')) {
				valid=0;
				break;
			}

		}
		if(valid) {
			k=0;
			printf("Valid name format\n");
		}
		else {
			printf("Your Name is Not in Correct Format\n");
		}
	}
}
char validateMobileNumber(char *str, AddressBook *addressBook) {
	int k=1;
	while(k) {
		int c=0,valid=1;
		printf("Enter Mobile Number: ");
		scanf("%s", str);
		for(int i=0; str[i]!='\0';i++) {
			if(str[i]>='0' && str[i]<='9') {
				c++;
				continue;
			}
			else {

				valid=0;
				break;
			}
		}
		if(c!=10) {
			valid=0;
		}
		if(valid) {
			k=0;
			printf("Valid Mobile Number format\n");
		}
		else {
			printf("Your Mobile Number is Not in Correct Format\n");
		}
	}
}
char validateEmail(char *str, AddressBook *addressBook){
	int k=1;
	while(k) {
		int valid=1;
		printf("Enter Your Email: ");
		scanf("%s", str);
		getchar();
		char *email=str;
		int len=strlen(email);
		char ch;
		int Index = -1;
		for (int i = 0; i < len; i++) {
			if (email[i] == '@') {
				Index = i;
				break;
			} else if(!((email[i]>='a' && email[i]<='z' ) ||(email[i]>='A' && email[i]<='Z') || (email[i]>='0' && email[i]<='9'))) {
				valid=0;
				break;
			}

		}
		if (Index == -1 || Index < 1 || Index >= len - 5) {
			valid = 0;
		} else {
			for (int i = Index + 1; i < len - 4; i++) {
				ch = email[i];
				if (!((ch >= 'a' && ch <= 'z'))) {
					valid = 0;
					break;
				}
			}
		}
		if (strcmp(&email[len - 4], ".com") != 0) {
			valid = 0;
		}
		if(valid) {
			k=0;
			printf("Valid Email Number format\n");
		}
		else {
			printf("Your Email Number is Not in Correct Format\n");
		}
	}

}   
char validateDuplicateEmail(char *str, AddressBook *addressBook) {
	int n= addressBook->contactCount;
	for(int i=0;i<n;i++) {
		if(strcmp(str, addressBook->contacts[i].email) == 0) {
			return 1;
		}



	}
	return 0;

}
char validateDuplicateMobileNumber(char *str, AddressBook *addressBook) {                                                                                           int n= addressBook->contactCount;                                                                                                                           for(int i=0;i<n;i++) {                                                                                                                                              if(strcmp(str, addressBook->contacts[i].phone) == 0) {                                                                                                          return 1;                                                                                                                                                  }                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    }                                                                                                                                                           return 0;                                                                                                                                                                                                                                                                                                           }


void createContact(AddressBook *addressBook)
{
	//printf("%d",addressBook->contactCount);
	if (addressBook->contactCount >= MAX_CONTACTS) {
		printf("Contacts reached Maximum\n");
		return;
	}

	validateName(addressBook->contacts[addressBook->contactCount].name, addressBook);
	int m=1;
	while(m) {
		validateMobileNumber(addressBook->contacts[addressBook->contactCount].phone, addressBook);      
		int c=validateDuplicateMobileNumber(addressBook->contacts[addressBook->contactCount].phone, addressBook);
		if(c) {
			printf("This Mobile Number is already there in contact list\n");
			printf("\tAgain Enter different Mobile Number\n");
		}
		else {
			m=0;
		}
	}
	m=1;
	while(m) {

		validateEmail(addressBook->contacts[addressBook->contactCount].email, addressBook);
		int  c=validateDuplicateEmail(addressBook->contacts[addressBook->contactCount].email, addressBook);
		if(c) {
			printf("This Email is already there in contact list\n");
			printf("\tAgain Enter different Email\n");
		} else {
			m=0;
		}
	}
	addressBook->contactCount++;




}

void searchContact(AddressBook *addressBook) 
{
	int n=addressBook->contactCount;
	int m;
	Contact search;
	printf("Please Select one option which contact you want to search by using name, mobile number and email\n");
	printf("1.Name\n2.Mobile Number\n3.email\n");
	scanf("%d", &m);
	int k=1, valid=1,c=0;
	int foundIndex[100];
	if(m==1) {
		while(k) {
			valid=1;
			validateName(search.name, addressBook);
			for(int i=0;i<n;i++) {
				if(strcmp(search.name, addressBook->contacts[i].name)==0) {
					foundIndex[c]=i;
					c++;
					valid=1;
				}

			}
			if(c==0) {
				valid=0;
			}
			if(valid) {
				k=0;
			}
			else {
				printf("This name is Not there in Contactlist\n");
			}
		}
		if(c==1) {
			printf("+-------------------------------------+-----------------+---------------------------------------+\n");
			printf("| %-35s | %-15s | %-37s |\n", "Name", "Phone Number", "Email");
			printf("+-------------------------------------+-----------------+---------------------------------------+\n");
			printf("| %-35s | %-15s | %-37s |\n", addressBook->contacts[foundIndex[0]].name,  addressBook->contacts[foundIndex[0]].phone,  addressBook->contacts[foundIndex[0]].email);
			printf("+-------------------------------------+-----------------+---------------------------------------+\n");
		}
		if(c>1) {
			for(int i=0;i<c;i++) {
				printf("%d %s %s %s\n",i+1, addressBook->contacts[foundIndex[i]].name,  addressBook->contacts[foundIndex[i]].phone,  addressBook->contacts[foundIndex[i]].email);
			}
			int select;
			printf("Select serial Number which contact do you want: ");
			scanf("%d", &select);
			select--;
			printf("+-------------------------------------+-----------------+---------------------------------------+\n");
			printf("| %-35s | %-15s | %-37s |\n", "Name", "Phone Number", "Email");
			printf("+-------------------------------------+-----------------+---------------------------------------+\n");
			printf("| %-35s | %-15s | %-37s |\n", addressBook->contacts[foundIndex[select]].name,  addressBook->contacts[foundIndex[select]].phone,  addressBook->contacts[foundIndex[select]].email);
			printf("+-------------------------------------+-----------------+---------------------------------------+\n");

		}
	}
	if(m==2) {
		while(k) {
			valid=1;
			validateMobileNumber(search.phone, addressBook);
			for(int i=0;i<n;i++) {
				if(strcmp(search.phone, addressBook->contacts[i].phone)==0) {

					printf("+-------------------------------------+-----------------+---------------------------------------+\n");
					printf("| %-35s | %-15s | %-37s |\n", "Name", "Phone Number", "Email");

					printf("+-------------------------------------+-----------------+---------------------------------------+\n");
					printf("| %-35s | %-15s | %-37s |\n", addressBook->contacts[i].name,  addressBook->contacts[i].phone,  addressBook->contacts[i].email);

					printf("+-------------------------------------+-----------------+---------------------------------------+\n");
					valid=1;
					break;
				}
				else {
					valid=0;
				}
			}
			if(valid) {
				k=0;
			}
			else {
				printf("This Mobile Number is not there in Contactlist\n");
			}
		}
	}
	if(m==3) {
		while(k) {
			valid=1;
			validateEmail(search.email,  addressBook);

			for(int i=0;i<n;i++) {
				if(strcmp(search.email, addressBook->contacts[i].email)==0) {

					printf("+-------------------------------------+-----------------+---------------------------------------+\n");
					printf("| %-35s | %-15s | %-37s |\n", "Name", "Phone Number", "Email");

					printf("+-------------------------------------+-----------------+---------------------------------------+\n");
					printf("| %-35s | %-15s | %-37s |\n", addressBook->contacts[i].name,  addressBook->contacts[i].phone,  addressBook->contacts[i].email);

					printf("+-------------------------------------+-----------------+---------------------------------------+\n");
					valid=1;
					break;
				}
				else {
					valid=0;
				}
			}
			if(valid) {
				k=0;
			}
			else {
				printf("This email is not there in Contactlist\n");
			}
		}
	}
}

void editContact(AddressBook *addressBook)
{

	int n=addressBook->contactCount;
	int m;
	int index=-1;
	Contact search;
	char edit[50];
	printf("Please Select one option which one you want to edit  name, mobile number and email\n");
	printf("1.Name\n2.Mobile Number\n3.email\n");
	scanf("%d", &m);
	int k=1, valid=1,c=0;

	int foundIndex[50]; 
	if(m==1) {     
		while(k) {
			valid=1;
			validateName(search.name, addressBook);
			for(int i=0;i<n;i++) {
				if(strcmp(search.name, addressBook->contacts[i].name)==0) {
					index=i;
					foundIndex[c++]=i;
					valid=1;

				}
			}
			if(c==0) {
				valid=0;
			}
			if(valid) {
				k=0;
			}
			else {
				printf("This Name is Not there in ContactList\n");
			}

		}
		if (c > 1) {
			for (int i = 0; i < c; i++) {
				printf("%d. %s %s %s\n", i + 1, addressBook->contacts[foundIndex[i]].name,
						addressBook->contacts[foundIndex[i]].phone,
						addressBook->contacts[foundIndex[i]].email);
			}
			int select;
			printf("Select the serial number of the contact you want to edit: ");
			scanf("%d", &select);
			if (select < 1 || select > c) {
				printf("Invalid selection.\n");
				return;
			}
			select--; 
			index = foundIndex[select]; 
		} else {
			index = foundIndex[0]; 
		}

		printf("\tEnter a new name:\n");
		validateName(edit, addressBook); 
		strcpy(addressBook->contacts[index].name, edit); 
		printf("Name edited successfully!\n");


	}
	if(m==2) {
		int k=1;
		while(k) {
			int valid=1;
			validateMobileNumber(search.phone, addressBook);

			for(int i=0;i<n;i++) {
				if(strcmp(search.phone, addressBook->contacts[i].phone)==0) {
					index=i;
					valid=1;
					break;
				}
				else {
					valid=0;
				}
			}
			if(valid) {
				k=0;
			}
			else {
				printf("This Mobile Number is not their in ContactList\n");
			}
		}
		int m=1;
		while(m) {
			printf("\tEnter New Mobile Number\n");
			validateMobileNumber(edit, addressBook);
			char c=validateDuplicateMobileNumber(edit, addressBook);                                                                                                   if(c) {                                                                                                                                                            printf("This Mobile Number is already there in contact list\n");                                                                                            printf("\tAgain Enter different Mobile Number\n");                                                                                                            }
			else {
				m=0;
			}
		}
		strcpy(addressBook->contacts[index].phone, edit);
		printf("Mobile Number Edited Successfully!\n");


	}

	if(m==3) {
		int k=1;
		while(k) {
			int valid=1;
			validateEmail(search.email, addressBook);
			for(int i=0;i<n;i++) {
				if(strcmp(search.email, addressBook->contacts[i].email)==0) {
					index=i;
					valid=1;
					break;
				}
				else {
					valid=0;
				}
			}
			if(valid) {
				k=0;
			}
			else {
				printf("This Email is not there in ContactList\n");
			}

		}

		int m=1;
		while(m) {
			printf("\tEnter New Email\n");
			validateEmail(edit, addressBook);
			char c=validateDuplicateEmail(edit, addressBook);                                                                                                   if(c) {                                                                                                                                                            printf("This Email is already there in contact list\n");                                                                                            printf("\tAgain Enter different Email\n");                                                                                                                       } else {
				m=0;
			}
		} 
		strcpy(addressBook->contacts[index].email, edit);
		printf("Email Edit Successfully!\n");




	}
}


void deleteContact(AddressBook *addressBook)
{

	int n=addressBook->contactCount;
	int m;
	int ind;
	Contact delete;
	printf("Please Select one option which one you want to edit  name, mobile number and email\n");
	printf("1.Name\n2.Mobile Number\n3.email\n");
	scanf("%d", &m);
	int k=1, valid=1,c=0;
	int foundindex[100];
	if(m==1) {
		while(k) {
			valid=1;
			validateName(delete.name, addressBook);
			for(int i=0;i<n;i++) {
				if(strcmp(delete.name, addressBook->contacts[i].name)==0) {
					ind=i;
					foundindex[c]=i;
					c++;
					valid=1;
				}

			}
			if(c==0) {
				valid=0;
			}
			if(valid) {
				k=0;
			}
			else {
				printf("This is Not there in Contact lists\n");
			}

		}
		if(c==1) {
			for (int i = ind; i < n - 1; i++) {
				addressBook->contacts[i] = addressBook->contacts[i + 1];
			}

			addressBook->contactCount--;
			printf("Contact Deleted Sucessfully!");
		}
		else if(c>1) {
			for (int i = 0; i < c; i++) {
				printf("%d.%s %s %s\n", i+1,  addressBook->contacts[foundindex[i]].name,addressBook->contacts[foundindex[i]].phone,addressBook->contacts[foundindex[i]].email);
			}
			int select;
			printf("Select serial Number Which contact you want to Delete: ");
			scanf("%d", &select);
			select--;
			int selectIndex=foundindex[select];
			for (int i = selectIndex; i < n - 1; i++) {
				addressBook->contacts[i] = addressBook->contacts[i + 1];
			}
			addressBook->contactCount--;
			printf("Contact Deleted Sucessfully!\n");
		}
	}
	if(m==2) {

		while(k) {
			valid=1;
			printf("\tWhich Mobile Number do you want to delete\n");
			validateMobileNumber(delete.phone, addressBook);
			for(int i=0;i<n;i++) {
				if(strcmp(delete.phone, addressBook->contacts[i].phone)==0) {
					ind=i;
					valid=1;
					break;
				} else {
					valid=0;
				}

			}
			if(valid) {
				k=0;
			}
			else {
				printf("This is Not there in Contact lists\n");
			}

		}
		for (int i = ind; i < n - 1; i++) {
			addressBook->contacts[i] = addressBook->contacts[i + 1];
		}
		addressBook->contactCount--;
		printf("Contact Deleted Sucessfully!");
	}
	if(m==3) {

		while(k) {
			valid=1;
			printf("\tWhich email do You want to Delete\n");
			validateEmail(delete.email, addressBook);
			for(int i=0;i<n;i++) {
				if(strcmp(delete.email, addressBook->contacts[i].email)==0) {
					ind=i;
					valid=1;
					break;
				} else {
					valid=0;
				}

			}
			if(valid) {
				k=0;
			}
			else {
				printf("This is Not there in Contact lists\n");
			}

		}
		for (int i = ind; i < n - 1; i++) {
			addressBook->contacts[i] = addressBook->contacts[i + 1];
		}
		addressBook->contactCount--;
		printf("Contact Deleted Sucessfully!");
	}    
}

