#include "header.h"

/* Function to count the number of digits in a number */
int check_zeros(int num)
{
    int cnt = 0;  // Variable to store the count of digits
    while ( num )  // Loop until the number becomes zero
    {
        cnt++;  // Increment the count for each digit
        num = num / 10;  // Remove the last digit by dividing the number by 10
    }
    return cnt;  // Return the number of digits (this is essentially the length of the number)
}

/* Function to print the result stored in a singly linked list (Slist) */
void print_result_list(Slist *head)
{
    while (head)  // Iterate through the list until we reach the end
    {
        // Call check_zeros to get the number of digits in the current data node
        int temp = check_zeros(head->data);

        switch (temp)  // Switch case based on the number of digits in the current data
        {
            case 0:
            { 
                printf("0000");  // If the number has no digits (0), print "0000"
                head = head->link;  // Move to the next node in the list
                break;
            }

            case 1:
            {
                printf("000");  // If the number has 1 digit, print "000" followed by the number
                printf("%d", head->data);
                head = head->link;  // Move to the next node
                break;
            }
                
            case 2:
            {
                printf("00");  // If the number has 2 digits, print "00" followed by the number
                printf("%d", head->data);
                head = head->link;  // Move to the next node
                break;
            }

            case 3:
            {
                printf("0");  // If the number has 3 digits, print "0" followed by the number
                printf("%d", head->data);
                head = head->link;  // Move to the next node
                break;
            }

            case 4:
            {
                printf("%d", head->data);  // If the number has 4 digits, just print the number
                head = head->link;  // Move to the next node
                break;
            }
        }
    }
    printf("\n");  // Print a newline at the end of the output
}

