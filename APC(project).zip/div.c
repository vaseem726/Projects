#include"header.h"
Status create_dlll_arg(Dlist **head , Dlist **tail , int len, char operand[] );

int need_repeat_function(char [] , char []);
void print_list(Dlist *head)
{
	/* Cheking the list is empty or not */
	if (head == NULL)
	{
		printf("INFO : List is empty\n");
	}
	else
	{
 	    while (head)		
	    {
		    /* Printing the list */
		    printf("%d", head -> data);

		    /* Travering in forward direction */
		    head = head -> next;
	    }
     }
}
Status perform_Division (char *argv[])
{
    Dlist *head1 = NULL , *head2 = NULL , *tail1 = NULL , *tail2 = NULL;
    int len_of_operand1 = strlen(argv[1]);  //calculate the length of operand1 
    int len_of_operand2 = strlen(argv[3]);  //calculate the length of operand2  

    char operand1[len_of_operand1];
    strcpy(operand1 , argv[1]);

    char operand2[len_of_operand2];
    strcpy(operand2 , argv[3]);

    /*perform insert at first and create the list*/
    create_dlll_arg( &head1 , &tail1 , len_of_operand1 , operand1  );
    create_dlll_arg( &head2 , &tail2 , len_of_operand2 , operand2  );
    //print_list(head1);
    //printf("\n");
    //print_list(head2);

    int repeat_flag = 1;
    Dlist *head3 = NULL , *tail3 = NULL;
    int data1 = 0 , data2 = 0 , result = 0 , carry = 0 ;
    Dlist *prev2 = tail2;
    unsigned long long int final_result = 0;

    while( repeat_flag )
    {       
      Dlist *r_head = NULL , *r_tail = NULL;
      //carry = 0;
      tail2 = prev2;       

      while( tail2 != NULL || tail3 != NULL )
      {
        //result = 0;
        if ( tail2 != NULL )
        {
          data1 = tail2->data;
          //printf("\nt2:%d  ",data1);
          tail2 = tail2->prev;
        }
        else 
        data1 = 0;

        if ( tail3 != NULL )
        {
          data2 = tail3->data;
          //printf("t3: %d\n",data2);
          tail3 = tail3->prev;
        }
        else
        data2 = 0;

        result = data1 + data2 + carry;
        if ( result > 9 )
        {
          carry = result / 10 ;
          result = result % 10 ;
        }
        else
        carry = 0;

        Dlist *newNode = malloc(sizeof(Dlist));
        if ( newNode == NULL )
        return FAILURE;

        newNode->data = result;
        newNode->prev = NULL;
        newNode->next = NULL;

        if ( r_head == NULL )
        {
          r_head = newNode;
          r_tail = newNode;
        }
        else
        {
          r_head->prev = newNode;
          newNode->next = r_head;
          r_head = newNode;
        }
      }/*Prasad Shinde*/
      if ( carry > 0 )
      { 
          Dlist *newNode = malloc(sizeof(Dlist));
          if ( newNode == NULL)
          return FAILURE;
          newNode->data = carry;
          newNode->prev = NULL;
          newNode->next = NULL;

          r_head->prev = newNode;
          newNode->next = r_head;
          r_head = newNode;
          carry = 0;
        
      }
      head3 = r_head;
      tail3 = r_tail ;      
      tail2 = prev2;

      //printf("\n");
      //print_list(head3);  

      /*static int prasad = 1;
        if ( prasad > 5 )
        {
            repeat_flag = 0;
        }  
        prasad++; */

       char buff[100];  //buffer to store the 
       int j = 0;
      while (r_head != NULL)  //collect each digit from result list and store in string for comparision
      {
        int temp_data = r_head->data;           
        char rem = temp_data   + '0';
                 
        buff[j ] = rem   ;
        //printf(" : %c  ",buff[j]);
        j++;              
        r_head = r_head->next;
      }
      buff[j] = '\0';
      //printf("\n\nbuff%s\n",buff);
       
       final_result++;
       if ( need_repeat_function ( buff , operand1) != 1 )  //function which will check which number is larger arg3 or subtraction_result
        {
            repeat_flag = 0;
        }   
       
    }
    printf("\n%lld\n",final_result-1);
    return SUCCESS;
}


int need_repeat_function(char buff[] , char op1[])
{
     
    int l1 = strlen(op1);
    int l2 = strlen(buff);
    //printf("len of buf :%d\n",l1);

     //printf("len of buf :%d\n",l2);


    if  ( l1 > l2 ){
     //printf("largs\n");
    return 1;
    
    }

    for ( int i = 0 ; i< l1 ; i++ )
    {
       if ( op1 [i] ==  buff[i]) 
       {
        continue;
       }
       else if ( (op1 [i] > buff[i])   )
        {

            return 1;            
        }
        else
        {
          //printf("no\n");
        return  0;
        }

    }  
    return 0;
}

Status create_dlll_arg(Dlist **head , Dlist **tail , int len, char operand[] ) 
{
    for ( int i = len - 1 ; i >= 0 ; i--)
    {
        Dlist *newNode = malloc(sizeof(Dlist));
        if ( newNode == NULL )
        {
            printf("Node not created\n");       
            return FAILURE;
        }
         
        int value = operand[i] - '0' ;
        newNode->data = value;
        newNode->prev = NULL;
        newNode->prev = NULL;

        if ( *head == NULL)
        {
            *head = newNode;
            *tail = newNode;
        }
        else
        {
            (*head)->prev = newNode;
            newNode->next = *head;
            *head = newNode;
        }
    } 

}

