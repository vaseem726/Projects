#include"header.h"
Status create_dll_arg(Dlist **head , Dlist **tail , int len, char operand[] );
void final_multiplication( Dlist **h1 , Dlist **t1 , Dlist **h2  , Dlist **t2);

void print(Dlist *head)
{
	/* Cheking the list is empty or not */
	if (head == NULL)
	{
		printf("INFO : List is empty\n");
	}
	else
	{
 	    while (head)		
	    {
		    /* Printing the list */
		    printf("%d", head -> data);

		    /* Travering in forward direction */
		    head = head -> next;
	    }
     }
}
Status perform_Multiplication( char *argv[])
{ 
    Dlist *head1 = NULL , *head2 = NULL , *tail1 = NULL , *tail2 = NULL;

    int len_of_operand1 = strlen(argv[1]);  //calculate the length of operand1 
    int len_of_operand2 = strlen(argv[3]);  //calculate the length of operand2  

    char operand1[len_of_operand1];
    strcpy(operand1 , argv[1]);

    char operand2[len_of_operand2];
    strcpy(operand2 , argv[3]);  

    /*perform insert at first and create the list*/
    create_dll_arg( &head1 , &tail1 , len_of_operand1 , operand1  );
    create_dll_arg( &head2 , &tail2 , len_of_operand2 , operand2  );
   // print(head1);
    //print(head2);

    /*perfrom multiplication*/
    Dlist *r_head = NULL , *r_tail = NULL , *temp = NULL;
    int carry = 0 ;
    int add_zeros = 0;
    Dlist *final_head = NULL , *final_tail = NULL;

    while( tail2 != NULL)
    {
        int digit = tail2->data;
       // printf("digit : %d\n",digit);
        temp = tail1;
        r_head = NULL , r_tail = NULL;
        //printf("temodata : %d\n",temp->data);
        while(tail1 != NULL)
        {  
           // printf("tail1data : %d\n",tail1->data);
             int value = ( digit * tail1->data) + carry;
           // printf("value : %d\n",value);
            if ( value > 9 )
            {
                carry = value / 10;
                value = value % 10;
            }
            else
            {
                carry = 0;
            }

            /*create node and perform insert at first operation*/
            Dlist *newNode = malloc(sizeof(Dlist));
            if ( newNode == NULL )
            {
                printf("Node not created\n");
                return FAILURE;
            }

            newNode->data = value;
            newNode->prev = NULL;
            newNode->next = NULL;

            if ( r_head == NULL)
            {
                r_head = newNode;
                r_tail = newNode;
            }
            else
            {
                r_head->prev = newNode;
                newNode->next = r_head;
                r_head = newNode;
            }

            tail1 = tail1->prev;
        }
        if ( carry > 0 )  //create node for carry and perform insert at first
        {
            Dlist *newNode = malloc(sizeof(Dlist));
            if ( newNode == NULL)
            return FAILURE;
            newNode->data = carry;
            newNode->prev = NULL;
            newNode->next = NULL;

            r_head->prev = newNode;
            newNode->next = r_head;
            r_head = newNode;
            carry = 0;
        }     
       for ( int i = 1 ; i <= add_zeros ; i++ )  //create node for extra zeros and perform insert at last
       {
          Dlist *newNode = malloc(sizeof(Dlist));
          if (newNode == NULL)
          return FAILURE;

          newNode->data = 0;
          newNode->next = NULL;
          newNode->prev = NULL;

          r_tail->next = newNode;
          newNode->prev = r_tail;
          r_tail = newNode;         
       }
       
        //printf("\n");
        // print(r_head);  
       add_zeros++;
       tail1 = temp;   //move the pointer at initial  condition
       tail2 = tail2->prev; //take another digit
       final_multiplication( &final_head , &final_tail , &r_head , &r_tail);  //Actual funtion of for multiplication

    } 
         printf("\n");
         print(final_head); 
         printf("\n");  
         return SUCCESS; 
}
Status create_dll_arg(Dlist **head , Dlist **tail , int len , char operand[] )  //creates DLL for operands
{
    for ( int i = len - 1 ; i >= 0 ; i--)
    {
        Dlist *newNode = malloc(sizeof(Dlist));
        if ( newNode == NULL )
        {
            printf("Node not created\n");       
            return FAILURE;
        }
         
        int value = operand[i] - '0' ;
        newNode->data = value;
        newNode->prev = NULL;
        newNode->prev = NULL;

        if ( *head == NULL)
        {
            *head = newNode;
            *tail = newNode;
        }
        else
        {
            (*head)->prev = newNode;
            newNode->next = *head;
            *head = newNode;
        }
    }

}

 void final_multiplication( Dlist **final_head , Dlist **final_tail , Dlist **r_head  , Dlist **r_tail)
 {
    Dlist *head = NULL , *tail = NULL;  

    int data1 = 0 , data2 = 0 , result = 0 , carry = 0;
    while( (*final_tail ) != NULL || ( *r_tail) != NULL )
    {
        if ( (*r_tail ) != NULL )
        {
            data1 = (*r_tail)->data;
            (*r_tail) = (*r_tail)->prev;
        }
        else
        data1 = 0;

        if ( (*final_tail) != NULL)
        {
            data2 = (*final_tail)->data;
            (*final_tail) = (*final_tail)->prev;
        }
        else
        data2 = 0;

        result = data1 + data2 + carry;
        if ( result > 9 )
        {
            carry = result / 10;
            result = result % 10;
        }
        else
        carry = 0;

        Dlist *newNode = malloc(sizeof(Dlist));
        newNode->data = result;
        newNode->next = NULL;
        newNode->prev = NULL;

        if ( head == NULL)
        {
            head = newNode;
            tail = newNode;
        }
        else
        {
            head->prev = newNode;
            newNode->next = head;
            head = newNode;
        }   
    }
    if (carry > 0 )
    {
        Dlist *newNode = malloc(sizeof(Dlist));
        newNode->data = carry;
        newNode->prev = NULL;
        newNode->next = NULL;

        head->prev = newNode;
        newNode->next = head;
        head = newNode;
    }
    (*final_head) = head;  //update the result list head and tail
    (*final_tail ) = tail;
 }

