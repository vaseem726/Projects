#include "header.h"

Status perform_Addition(char *argv[]) 
{
    // Declare pointers for doubly linked lists (head and tail for both operands)
    Dlist *head1 = NULL, *head2 = NULL, *tail1 = NULL, *tail2 = NULL;
    
    // Declare a singly linked list to store the result
    Slist *head = NULL;

    // Calculate the length of operand1 (argv[1]) and operand2 (argv[3])
    int len_of_operand1 = strlen(argv[1]);
    int len_of_operand2 = strlen(argv[3]);

    // Adjust the alignment of the operands based on their length for proper display
    if (len_of_operand1 > len_of_operand2) 
    {
        int sp = len_of_operand1 - len_of_operand2; // Calculate space difference
        printf("%s\n", argv[1]);
        for (int i = 1; i <= sp; i++)  // Print spaces to align the operands
            printf(" ");
        printf("%s\n", argv[3]);
    } 
    else if (len_of_operand2 > len_of_operand1) 
    {
        int sp = len_of_operand2 - len_of_operand1;  // Calculate space difference
        for (int i = 1; i <= sp; i++)  // Print spaces to align the operands
            printf(" ");
        printf("%s\n", argv[1]);
        printf("%s\n", argv[3]);
    } 
    else 
    {
        // If operands have the same length, simply print them
        printf("%s\n", argv[1]);
        printf("%s\n", argv[3]);
    }

    // If either operand is less than 4 digits, convert them to integers and perform simple addition
    if (len_of_operand1 < 4 || len_of_operand2 < 4) 
    {
        int operand1 = atoi(argv[1]); // Convert operand1 to integer
        int operand2 = atoi(argv[3]); // Convert operand2 to integer
        printf("\n%d\n", operand1 + operand2);  // Print the result of addition
        return SUCCESS;
    }

    // Calculate the necessary parameters to process operand1 (block-wise handling)
    char operand1[len_of_operand1];
    strcpy(operand1, argv[1]);
    int rem_of_operand1 = len_of_operand1 % 4; // Calculate remainder (to handle block sizes)
    int flag1 = 1; // Flag to check if the length of operand1 % 4 is 0 (to handle the MSB block)
    if (rem_of_operand1 == 0) 
    {
        flag1 = 0;  // If the length is a multiple of 4, set flag to 0
    }
    char buffer_operand1[5];  // Buffer to store blocks of 4 digits of operand1
    char rem_buffer_operand1[rem_of_operand1];  // Buffer for the MSB block

    // Create a doubly linked list for operand1 (block-wise storage of digits)
    if (create_DLL(operand1, len_of_operand1, flag1, rem_of_operand1, buffer_operand1, rem_buffer_operand1, &head1, &tail1) == FAILURE) 
    {
        printf(RED "list not created\n" RESET);
    }

    // Repeat the same process for operand2 (similar block-wise handling)
    char operand2[len_of_operand2];
    strcpy(operand2, argv[3]);
    int rem_of_operand2 = len_of_operand2 % 4;
    int flag2 = 1;
    if (rem_of_operand2 == 0 )
    {
        flag2 = 0;
    }  
    char buffer_operand2[5];
    char rem_buffer_operand2[rem_of_operand2]; 

    if ( create_DLL ( operand2, len_of_operand2 , flag2 , rem_of_operand2 , buffer_operand2 , rem_buffer_operand2 ,  &head2  , &tail2 ) == FAILURE)
    {
        printf(RED"list not created\n"RESET);
    } 

    /*Perform addition operation*/
    printf("\n");    
    int data1 = 0 , data2 = 0 , result = 0 , carry = 0 ;
    while(tail1 != NULL || tail2 != NULL)
    {
        
        if ( tail1 != NULL )
        {
            data1 = tail1->data;
           // printf("data1 : %d\n",data1);
            tail1 = tail1->prev;
        }
        else
        {
            data1 = 0;
        }

        if ( tail2 != NULL)
        {
            data2 = tail2->data;
           // printf("data2 : %d\n",data2);
            tail2 = tail2->prev;
        }
        else
        {
            data2 = 0;
        }
        result = data1 + data2 + carry;
        if ( result >= 10000 )
        {
            carry = result / 10000;           
            result = result - 10000;            
        }
        else
        {
            carry = 0 ;
        }
        // printf("carry : %d\n",carry);
        //printf("result : %d\n",result);

        /*create the node and perform the insert at first operation on single linked list*/
        Slist *newNode = malloc (sizeof(Slist));
        if ( newNode == NULL)
        return FAILURE;

        newNode->data = result;
        newNode->link = head;

        head = newNode; 
    }
    if (carry > 0 )
    {
        Slist *newNode = malloc (sizeof(Slist));
        if ( newNode == NULL)
        return FAILURE;

        newNode->data = carry;
        newNode->link = head;

        head = newNode; 
    }

    print_result_list(head);
    return SUCCESS;
}
 
 

