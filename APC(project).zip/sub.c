#include "header.h"

Status perform_Subtraction(char *argv[]) 
{
    // Declare pointers for doubly linked lists to store the two operands and their tails
    Dlist *head1 = NULL, *head2 = NULL, *tail1 = NULL, *tail2 = NULL;

    // Declare a singly linked list to store the result
    Slist *head = NULL;

    // Flag to check if the result should be negative
    int check_sign_flag = 0; 

    // Calculate the lengths of operand1 (argv[1]) and operand2 (argv[3])
    int len_of_operand1 = strlen(argv[1]);
    int len_of_operand2 = strlen(argv[3]);

    // Copy operands into local variables for easier handling
    char operand1[len_of_operand1];    
    strcpy(operand1, argv[1]);
    char operand2[len_of_operand2];
    strcpy(operand2, argv[3]);

    // Adjust space for aligning operands when printing
    if (len_of_operand1 > len_of_operand2) 
    {
        int sp = len_of_operand1 - len_of_operand2; // Calculate space difference
        printf("%s\n", argv[1]);
        for (int i = 1; i <= sp; i++)  // Print spaces to align operand2 under operand1
            printf(" ");
        printf("%s\n", argv[3]);
    } 
    else if (len_of_operand2 > len_of_operand1) 
    {
        check_sign_flag = 1;  // Set flag to check if the result will be negative
        int sp = len_of_operand2 - len_of_operand1; // Calculate space difference
        for (int i = 1; i <= sp; i++)  // Print spaces to align operand1 under operand2
            printf(" ");
        printf("%s\n", argv[1]);
        printf("%s\n", argv[3]);
    } 
    else 
    {
        // If operands have the same length, print them and compare each character
        printf("%s\n", argv[1]);
        printf("%s\n", argv[3]);
        for (int i = 0; i < len_of_operand1; i++) 
        {
            if (operand2[i] > operand1[i]) 
            {
                check_sign_flag = 1;  // Set flag if operand2 is larger than operand1
            }
        }
    }

    // If either operand is less than 4 digits, convert them to integers and perform simple subtraction
    if (len_of_operand1 < 4 || len_of_operand2 < 4) 
    {
        int operand1 = atoi(argv[1]);
        int operand2 = atoi(argv[3]);
        printf("\n%d\n", operand1 - operand2);
        return SUCCESS;
    }

    // Calculate the remainder of operand1 and operand2 lengths when divided by 4
    int rem_of_operand1 = len_of_operand1 % 4;
    int flag1 = 1;
    if (rem_of_operand1 == 0) 
    {
        flag1 = 0;  // If length is a multiple of 4, set flag to 0
    }

    // Buffers to store blocks of 4 digits for operand1 and operand2
    char buffer_operand1[5]; 
    char rem_buffer_operand1[rem_of_operand1]; 

    int rem_of_operand2 = len_of_operand2 % 4;
    int flag2 = 1;
    if (rem_of_operand2 == 0) 
    {
        flag2 = 0;  // If length is a multiple of 4, set flag to 0
    }
    char buffer_operand2[5];
    char rem_buffer_operand2[rem_of_operand2]; 

    // Decide which operand should be the first operand in the result list
    int flag_for_create_list = 0; 
    if (len_of_operand1 > len_of_operand2) 
    {
        flag_for_create_list = 1;  // Operand1 will be the first operand in the result
    } 
    else if (len_of_operand2 > len_of_operand1) 
    {
        flag_for_create_list = 0;  // Operand2 will be the first operand in the result
    } 
    else if (len_of_operand1 == len_of_operand2) 
    {
        // If operands have equal length, compare digit by digit
        for (int i = 0; i < len_of_operand1; i++) 
        {
            if (operand1[i] > operand2[i]) 
            {
                flag_for_create_list = 1;  // Operand1 is larger, so it will be first
                break;
            }
            else if (operand2[i] > operand1[i]) 
            {
                flag_for_create_list = 0;  // Operand2 is larger, so it will be first
                break;
            }
        }
    }

    // Create doubly linked lists for both operands based on the size of the operands
    if (flag_for_create_list) 
    {
        // Create DLL for operand1 and operand2
        if (create_DLL(operand1, len_of_operand1, flag1, rem_of_operand1, buffer_operand1, rem_buffer_operand1, &head1, &tail1) == FAILURE) 
        {
            printf(RED "list not created\n" RESET);
        }
        if (create_DLL(operand2, len_of_operand2, flag2, rem_of_operand2, buffer_operand2, rem_buffer_operand2, &head2, &tail2) == FAILURE) 
        {
            printf(RED "list not created\n" RESET);
        }
    } 
    else 
    {
        // Swap the creation of operand1 and operand2 DLLs if operand2 is larger
        if (create_DLL(operand2, len_of_operand2, flag2, rem_of_operand2, buffer_operand2, rem_buffer_operand2, &head1, &tail1) == FAILURE) 
        {
            printf(RED "list not created\n" RESET);
        }
        if (create_DLL(operand1, len_of_operand1, flag1, rem_of_operand1, buffer_operand1, rem_buffer_operand1, &head2, &tail2) == FAILURE) 
        {
            printf(RED "list not created\n" RESET);
        }
    }

    // Perform the subtraction operation by iterating through the doubly linked lists
    int data1 = 0, data2 = 0, result = 0, carry = 0;
    while (tail1 != NULL || tail2 != NULL) 
    {
        if (tail1 != NULL) 
        {
            data1 = tail1->data;  // Get data from operand1's current block
            tail1 = tail1->prev;  // Move to the next block
        } 
        else 
        {
            data1 = 0;  // If no data left in operand1, set it to 0
        }

        if (tail2 != NULL) 
        {
            data2 = tail2->data;  // Get data from operand2's current block
            tail2 = tail2->prev;  // Move to the next block
        } 
        else 
        {
            data2 = 0;  // If no data left in operand2, set it to 0
        }

        // Perform the subtraction with handling for negative results (borrow)
        if ((data1 > data2) || (data1 == data2)) 
        {
            result = data1 - data2 - carry;  // No borrow required
            carry = 0;  // Reset carry
        } 
        else if (data1 < data2) 
        {
            result = (data1 + 10000) - data2 - carry;  // Handle borrow (adding 10000)
            carry = 1;  // Set carry for the next operation
        }

        // Create a new node for the result and insert it into the result list
        Slist *newNode = malloc(sizeof(Slist));
        if (newNode == NULL) 
        {
            return FAILURE;  // Memory allocation failure check
        }

        newNode->data = result;  // Store the result in the new node
        newNode->link = head;    // Link the new node to the result list
        head = newNode;          // Update the head of the result list
    }

    // Print the result with the correct sign
    printf("\n");
    if (check_sign_flag) 
    {
        printf("-");  // Print the negative sign if the result is negative
    }

    // Print the result from the result list
    print_result_list(head);

    return SUCCESS;  // Return success after completing the subtraction
}

