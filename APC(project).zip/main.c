#include "header.h"

int main(int arg, char *argv[]) 
{
    // Check if the number of command-line arguments is 4 (./a.out operand1 operator operand2)
    if (arg == 4)
    {
        // Declare pointers for doubly linked lists (likely to be used in the operations, though not shown in this snippet)
        Dlist *head1 = NULL, *head2 = NULL, *tail1 = NULL, *tail2 = NULL;

        // Retrieve the first character of the operator (argv[2] holds the operator)
        char ch = argv[2][0];

        // Switch statement to perform the operation based on the operator
        switch(ch) 
        {
            case '+':
            {
                // Display a message indicating the selected operation (Addition)
                printf("\n");
                printf(YELLOW "----------------------------Selected ADDITION Operation----------------------------\n" RESET);

                // Call perform_Addition function (presumably defined elsewhere), passing the arguments (argv[])
                // If the addition is successful, print a success message
                if (perform_Addition(argv) == SUCCESS)
                {
                    printf(GREEN "----------------------------Addition Performed Successfully---------------------------\n" RESET);
                }
                printf("\n");
                break;
            }

            case '-':
            {
                // Display a message indicating the selected operation (Subtraction)
                printf(YELLOW "----------------------------Selected SUBTRACTION Operation----------------------------\n" RESET);

                // Call perform_Subtraction function (presumably defined elsewhere)
                // If the subtraction is successful, print a success message
                if (perform_Subtraction(argv) == SUCCESS)
                {
                    printf(GREEN "---------------------------Subtraction Performed Successfully---------------------------\n" RESET);
                }
                break;
            }

            case '*':
            {
                // Display a message indicating the selected operation (Multiplication)
                printf(YELLOW "----------------------------Selected MULTIPLICATION Operation----------------------------\n" RESET);
                
                // Print the operands being multiplied (argv[1] and argv[3] are the first and second operands)
                printf("%s\n%s\n", argv[1], argv[3]);

                // Call perform_Multiplication function (presumably defined elsewhere)
                // If multiplication is successful, print a success message
                if (perform_Multiplication(argv) == SUCCESS)
                {
                    printf(GREEN "----------------------------Multiplication Performed Successfully----------------------------\n" RESET);
                }
                break;
            }

            case '/':
            {
                // Display a message indicating the selected operation (Division)
                printf(YELLOW "----------------------------Selected DIVISION Operation----------------------------\n" RESET);
                
                // Print the operands being divided (argv[1] and argv[3] are the operands)
                printf("%s\n%s\n", argv[1], argv[3]);

                // Call perform_Division function (presumably defined elsewhere)
                // If division is successful, print a success message
                if (perform_Division(argv) == SUCCESS)
                {
                    printf(GREEN "----------------------------Division Performed Successfully----------------------------\n" RESET);
                }
                break;
            }

            default:
            {
                // If the operator is not recognized (not +, -, *, or /), display an error message
                printf(RED "Error: Enter valid operator (+, -, *, /)\n" RESET);
            }
        }

    }
    else
    {
        // If the number of arguments is not 4, display an error message indicating the correct usage
        printf(RED "Error: Pass --> ./a.out operand1 operator operand2\n" RESET);
        printf(RED "For Multiplication --> operand1 '*' operand2\n" RESET);
    }
}

