#ifndef HEADER_H
#define HEADER_H

#include<stdio.h>
#include<string.h>
#include<stdlib.h>
typedef unsigned long long int ulint;
typedef int data_t;

/* COLOUR MACRO */
#define RESET   "\x1B[0m"
#define RED     "\x1B[31m"
#define GREEN   "\x1B[32m"
#define YELLOW  "\x1B[33m"
#define BLUE    "\x1B[34m"

typedef struct node
{
	struct node *prev;
	data_t data;
	struct node *next;
}Dlist;
/*Prasad Shinde*/
typedef struct s_node
{
    struct s_node *link;
    data_t data;
}Slist;

typedef enum s
{
    SUCCESS,
    FAILURE
}Status;

Status perform_Addition( char *argv[]  );
Status perform_Subtraction( char *argv[]);
Status perform_Multiplication( char *argv[]); 
Status perform_Division( char *argv[]);
Status create_DLL ( char operand[], int len  ,  int flag , int rem , char buffer[] , char rem_buff[] , Dlist **head1  , Dlist **tail1 );
void print_result_list(Slist *head);

 

#endif

