#include "header.h"
Status create_DLL(char operand[], int len, int flag, int rem, char buffer[], char rem_buff[], Dlist **head, Dlist **tail)
{
    int i;
    int k = 0, z = 0;   // `k` and `z` are counters used for managing the buffer and remainder
    int cnt = 0;  // `cnt` keeps track of how many bytes have been processed
    for (i = 0; i < len; i++)  // Iterate over the operand array (character string)
    {
        if (flag)  // flag == 1: Create the Most Significant Byte (MSB) block that does not fit in 4 bytes
        {
            if (k < rem)  // If `k` is less than the remainder (bytes that couldn't fit into 4-byte blocks)
            {
                rem_buff[k] = operand[i];   // Store bytes in the remainder buffer
                k++;  // Move to the next position in the remainder buffer
            }
            else
            {
                flag = 0;  // Once remainder is filled, switch to regular processing (flag = 0)
                int Number = atoi(rem_buff);  // Convert the remainder buffer (string) to an integer
                
                Dlist *newNode = malloc(sizeof(Dlist));  // Allocate memory for a new node in the doubly linked list
                if (newNode == NULL)  // Check if memory allocation was successful
                    return FAILURE;  // Return failure if memory allocation fails

                newNode->data = Number;  // Store the number in the node
                newNode->next = NULL;    // Set next pointer to NULL (last node)
                newNode->prev = NULL;    // Set prev pointer to NULL (last node)
                
                // Insert the new node at the end of the doubly linked list
                if (*head == NULL)  // If the list is empty
                {
                    *head = newNode;  // Set both head and tail to the new node
                    *tail = newNode;
                }
                else
                {
                    (*tail)->next = newNode;  // Link the current tail node to the new node
                    newNode->prev = *tail;    // Link the new node back to the current tail
                    *tail = newNode;          // Update the tail pointer to the new node
                }
                i--;  // Decrement `i` to process the current byte again in the next iteration
            }
        }
        else  // flag == 0: Regular case where the MSB block fits within 4 bytes
        {
            if (cnt % 4 == 0 && cnt != 0)  // Every time we have processed 4 bytes
            {
                int Number = atoi(buffer);  // Convert the 4-byte block (buffer) to an integer
                
                Dlist *newNode = malloc(sizeof(Dlist));  // Allocate memory for the new node
                if (newNode == NULL)  // Check if memory allocation was successful
                    return FAILURE;

                newNode->data = Number;  // Store the integer in the node
                newNode->next = NULL;    // Set next pointer to NULL
                newNode->prev = NULL;    // Set prev pointer to NULL

                // Insert the new node at the end of the doubly linked list
                if (*head == NULL)  // If the list is empty
                {
                    *head = newNode;  // Set both head and tail to the new node
                    *tail = newNode;
                }
                else
                {
                    (*tail)->next = newNode;  // Link the current tail node to the new node
                    newNode->prev = *tail;    // Link the new node back to the current tail
                    *tail = newNode;          // Update the tail pointer to the new node
                }

                z = 0;  // Reset buffer index to 0
                buffer[z] = operand[i];  // Start storing the next byte in the buffer
                z++;  // Move to the next position in the buffer
                cnt++;  // Increment the byte count
            }
            else
            {
                buffer[z] = operand[i];  // Store the current byte in the buffer
                z++;  // Move to the next position in the buffer
                cnt++;  // Increment the byte count
            }
        }
    }

    // After the loop, if `cnt` is a multiple of 4, we need to process the last 4 bytes
    if (i == len && cnt % 4 == 0)  // If the loop ends and there are exactly 4 bytes left to process
    {
        Dlist *newNode = malloc(sizeof(Dlist));  // Allocate memory for the new node
        if (newNode == NULL)  // Check if memory allocation was successful
            return FAILURE;

        int Number = atoi(buffer);  // Convert the final 4-byte block (buffer) to an integer
        newNode->data = Number;  // Store the integer in the node
        newNode->next = NULL;    // Set next pointer to NULL (last node)
        newNode->prev = NULL;    // Set prev pointer to NULL (last node)

        // Insert the new node at the end of the doubly linked list
        if (*head == NULL)  // If the list is empty
        { 
            *head = newNode;  // Set both head and tail to the new node
            *tail = newNode;
        }
        else
        {
            (*tail)->next = newNode;  // Link the current tail node to the new node
            newNode->prev = *tail;    // Link the new node back to the current tail
            *tail = newNode;          // Update the tail pointer to the new node
        }
    }
}

